import os
import math

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
@login_required
def index():
    tempstocks = db.execute("SELECT * FROM stocks WHERE id = :id", id = session["user_id"])
    stocks_ = []
    total_ = 0
    for stock in tempstocks:
        templookup = lookup(stock["symbol"])
        temp = {
            "name": templookup["name"],
            "symbol": templookup["symbol"],
            "price": templookup["price"],
            "shares": stock["stockcount"],
            "total": float(templookup["price"]) * float(stock["stockcount"])
        }
        total_ += temp["total"]
        temp["price"] = usd(temp["price"])
        temp["total"] = usd(temp["total"])
        stocks_.append(temp)
    tempcash = db.execute("SELECT cash FROM users WHERE id = :id", id = session["user_id"])
    total_ += tempcash[0]["cash"]
    total_ = usd(total_)
    return render_template("index.html", stocks = stocks_, cash = usd(tempcash[0]["cash"]), total = total_)

@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    temp = None
    if request.method == "POST":
        symbol_ = request.form.get("symbol").upper()
        if not symbol_:
            return apology("must provide a symbol", 403)
        else:
            temp = lookup(symbol_)
            if (temp == None):
                return apology("invalid symbol")
        try:
            float(request.form.get("shares"))
        except ValueError:
            return apology("invalid number of shares", 400)
        rows = db.execute("SELECT * FROM users WHERE id = :id",
                          id = session["user_id"])
        cash_ = rows[0]["cash"] - float(temp["price"]) * float(request.form.get("shares"))
        if (cash_ >= 0):
            temprow = db.execute("SELECT * FROM stocks WHERE id = :id AND symbol = :symbol", id = session["user_id"], symbol = symbol_)
            if len(temprow) == 0:
                db.execute("INSERT INTO stocks (id, stockcount, symbol) VALUES(:id, :stockcount, :symbol)", id = session["user_id"], stockcount = request.form.get("shares"), symbol = symbol_)
            else:
                db.execute("UPDATE stocks SET id = :id, stockcount = :stockcount", id = session["user_id"], stockcount = int(request.form.get("shares")) + temprow[0]["stockcount"])
            db.execute("UPDATE users SET cash = :cash WHERE id = :id", cash = cash_, id = session["user_id"])
            db.execute ("INSERT INTO history (id, symbol, change, price, time) VALUES (:id, :symbol, :change, :price, strftime('%Y-%m-%d %H:%M:%S','now'))", id = session["user_id"],
                            symbol = symbol_, change = request.form.get("shares"), price = temp["price"])
            return redirect("/")
        return apology("not enough cash", 403)
    else:
        return render_template("buy.html")

    """Buy shares of stock"""

@app.route("/history")
@login_required
def history():
    historydb = db.execute("SELECT * FROM history WHERE id = :id ORDER BY time DESC", id = session["user_id"])
    history_ = []
    for item in historydb:
        temp = {
            "symbol": item["symbol"],
            "change": item["change"],
            "price": usd(item["price"]),
            "time": item["time"]
        }
        history_.append(temp)
    return render_template("history.html", history = history_)
    """Show history of transactions"""


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    if request.method == "POST":
        if not request.form.get("symbol"):
            return apology("must provide a symbol")
        else:
            temp = lookup(request.form.get("symbol"))
            if (temp == None):
                return apology("invalid symbol")
            else:
                return render_template("quoted.html", companyName = temp["name"], symbol = temp["symbol"], price = usd(temp["price"]))
    else:
        return render_template("quote.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 400)

        elif not request.form.get("password2"):
            return apology("must re-enter password", 400)
        elif request.form.get("password2") != request.form.get("password"):
            return apology("the passwords must match")

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) == 0:
            hash_ = generate_password_hash(request.form.get("password"))
            id_ = len(db.execute("SELECT * FROM users"))
            db.execute("INSERT INTO users (id, username, hash) VALUES(:id, :username, :hash)",
            id = id_, username = request.form.get("username"), hash = hash_)
        else:
            return apology("Username already exists", 400)

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("register.html")
    """Register user"""


@app.route("/cash", methods = ["GET", "POST"])
@login_required
def cash():
    if request.method == "POST":
        cash = request.form.get("amount")
        if not cash:
            return apology("Please enter an amount.", 400)
        try:
            cash = float(cash)
        except ValueError:
            return apology("Please enter a number with no symbols.", 400)
        db.execute("UPDATE users SET cash = cash + :amount WHERE id = :id", id = session["user_id"], amount = cash)
        return redirect("/")
    else:
        return render_template("cash.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    if request.method == "POST":
        if not request.form.get("symbol"):
            return apology("Please select a symbol.", 400)
        if not request.form.get("shares"):
            return apology("Please type the number of shares", 400)
        try:
             count = int(request.form.get("shares"))
        except ValueError:
            return apology("Please enter a number with no symbols.", 400)
        stock = db.execute("SELECT * FROM stocks WHERE id = :id AND symbol = :symbol", id = session["user_id"], symbol = request.form.get("symbol").upper())
        templookup = lookup(stock[0]["symbol"])
        if stock[0]["stockcount"] - count < 0:
            return apology("You don't have that many stocks!")
        db.execute("UPDATE users SET cash = cash + :cash WHERE id = :id", id = session["user_id"], cash = float(templookup["price"]) * float(count))
        if stock[0]["stockcount"] - count == 0:
            db.execute("DELETE FROM stocks WHERE id = :id AND symbol = :symbol", id = session["user_id"], symbol = templookup["symbol"])
        else:
            db.execute("UPDATE stocks SET stockcount = stockcount - :stockcount WHERE id = :id AND symbol = :symbol", id = session["user_id"], symbol = templookup["symbol"], stockcount = count)
        db.execute("INSERT INTO history (id, symbol, change, price, time) VALUES(:id, :symbol, :change, :price, strftime('%Y-%m-%d %H:%M:%S','now'))", id = session["user_id"],
        symbol = templookup["symbol"], change = -1 * count, price = templookup["price"])
        return redirect("/")
    else:
        tempsymbols = db.execute("SELECT symbol FROM stocks WHERE id = :id", id = session["user_id"])
        symbols_ = []
        for symbol in tempsymbols:
            symbols_.append(symbol["symbol"].upper())
        return render_template("sell.html", symbols = symbols_)


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
